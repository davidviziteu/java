CREATE TRIGGER before_insert1 BEFORE INSERT ON actorProduction
BEGIN
SELECT CASE 
WHEN ((SELECT actorProduction . id_movie FROM actorProduction WHERE actorProduction.id_movie = NEW.id_movie ) ISNULL) 
THEN RAISE(ABORT, 'This is an User Define Error Message - This movie does not exist.') 
END; 
END;

