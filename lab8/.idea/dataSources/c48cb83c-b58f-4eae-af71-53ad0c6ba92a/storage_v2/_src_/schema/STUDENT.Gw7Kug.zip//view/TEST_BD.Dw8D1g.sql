create view TEST_BD as
select nume, prenume from studenti
/

