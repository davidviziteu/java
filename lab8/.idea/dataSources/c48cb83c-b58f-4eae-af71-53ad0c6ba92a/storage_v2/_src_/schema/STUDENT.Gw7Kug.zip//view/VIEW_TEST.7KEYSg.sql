create view VIEW_TEST as
select nume, prenume from studenti where an=2
/

